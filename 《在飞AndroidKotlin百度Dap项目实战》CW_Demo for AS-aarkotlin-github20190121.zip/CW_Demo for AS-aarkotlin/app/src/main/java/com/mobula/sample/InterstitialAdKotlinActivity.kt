package com.mobula.sample

import android.app.Activity
import android.os.Bundle
import android.util.Log
import com.duapps.ad.InterstitialAd
import com.duapps.ad.InterstitialListener
import kotlinx.android.synthetic.main.ad_interstitial_kt.*

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/13-16:05
 */

class InterstitialAdKotlinActivity : Activity() {
    var TAG = InterstitialAdKotlinActivity::class.java.simpleName

    val PID2 = 130745
    lateinit var mInterstitialAd: InterstitialAd

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ad_interstitial_kt)

        mInterstitialAd = InterstitialAd(this, PID2, InterstitialAd.Type.SCREEN).apply {
            setInterstitialListener((object : InterstitialListener {
                override fun onAdClicked() {
                    Log.d(TAG, "onAdClicked")
                }

                override fun onAdDismissed() {
                    Log.d(TAG, "onAdDismissed")
                }

                override fun onAdFail(p0: Int) {
                    Log.d(TAG, "onAdFail")
                }

                override fun onAdPresent() {
                    Log.d(TAG, "onAdPresent")
                }

                override fun onAdReceive() {
                    Log.d(TAG, "onAdReceive")
                }
            }))

        }


        interstitial_kt_load.setOnClickListener {
            Log.d(TAG, "load....")
            mInterstitialAd.load()
        }
        interstitial_kt_show.setOnClickListener {
            Log.d(TAG, "show....")
            mInterstitialAd.show()
        }


    }


    override fun onDestroy() {
        super.onDestroy()
        mInterstitialAd.destroy()
    }
}