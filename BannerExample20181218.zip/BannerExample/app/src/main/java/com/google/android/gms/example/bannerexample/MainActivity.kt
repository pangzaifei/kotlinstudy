package com.google.android.gms.example.bannerexample

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.example.bannerexample.R.id.ad_view
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the Mobile Ads SDK with an AdMob App ID.
        MobileAds.initialize(this, "")

        // Create an ad request. If you're running this on a physical device, check your logcat to
        // learn how to enable test ads for it. Look for a line like this one:
        // "Use AdRequest.Builder.addTestDevice("ABCDEF012345") to get test ads on this device."
        val adRequest = AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)
                .build()

        // Start loading the ad in the background.
        ad_view.loadAd(adRequest)
    }

    // Called when leaving the activity
    public override fun onPause() {
        ad_view.pause()
        super.onPause()
    }

    // Called when returning to the activity
    public override fun onResume() {
        super.onResume()
        ad_view.resume()
    }

    // Called before the activity is destroyed
    public override fun onDestroy() {
        ad_view.destroy()
        super.onDestroy()
    }

    open class Father{
        var chactor="neixiang"
        open fun action(){
            println("father...")
        }
    }

    class Son:Father(){
        override fun action() {
            println("son...")
        }
    }

    enum class Week{
        day1,day2,day3
    }

    fun getDay(){
        Week.day1.ordinal
    }

    sealed class Son2{
        fun sayHello(){
            println("hello")
        }

        class xiaoxiaolv:Son2()
        class xiaoluozi:Son2()
    }

    fun getLv(){
        var s1:Son2=Son2.xiaoluozi()
        var s2:Son2=Son2.xiaoxiaolv()
        var s3:Son2=Son2.xiaoluozi()

        var lists= listOf<Son2>(s1,s2,s3)
        for(v in lists){
            if(v is Son2.xiaoluozi){
                v.sayHello()
            }
        }
    }

    fun getForEach(){
        var names= listOf<String>("a","b","c")
        names.forEach{
            print(it)
        }
    }


}



















