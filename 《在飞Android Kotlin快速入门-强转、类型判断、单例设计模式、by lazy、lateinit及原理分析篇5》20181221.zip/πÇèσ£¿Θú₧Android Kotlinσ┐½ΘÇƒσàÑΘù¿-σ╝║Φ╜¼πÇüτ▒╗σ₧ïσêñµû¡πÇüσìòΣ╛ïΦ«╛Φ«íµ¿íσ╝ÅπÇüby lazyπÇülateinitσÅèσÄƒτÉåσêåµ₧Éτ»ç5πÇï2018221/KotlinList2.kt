package com.google.android.gms.example.bannerexample

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.util.Log

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2018/12/21-15:35
 */
class KotlinList2 : Activity() {
    //by lazy
    val testByLazy by lazy {
        Log.e("fffpzf","初始化bylazy..")
        10
    }
    //lateinit
    lateinit var testLateInit: String//在这用lateinit会报错


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DuInput.getInstance(this@KotlinList2).start()
        TestInstance.start2()
        Log.e("fffpzf","testByLazy1:$testByLazy")
        Log.e("fffpzf","testByLazy2:$testByLazy")
    }

    fun testByLazy(){

    }

}




//普通class的类testObject1及内部的普通参数testData
class testObject1 {
    var testData = 10
}

//object修饰的类testObject2及内部object修饰的参数testData2
object testObject2 {
    var testObjectData2 = 10
}

class DuInput internal constructor(private val mContext: Context) {
    companion object {
        private var mDuInput: DuInput? = null
        fun getInstance(context: Context): DuInput {
            if (mDuInput == null) {
                synchronized(DuInput::class.java) {
                    if (mDuInput == null) {
                        mDuInput = DuInput(context)
                    }
                }
            }
            return mDuInput!!
        }
    }

    fun start() {}
}


object TestInstance {
    fun start2() {}
}