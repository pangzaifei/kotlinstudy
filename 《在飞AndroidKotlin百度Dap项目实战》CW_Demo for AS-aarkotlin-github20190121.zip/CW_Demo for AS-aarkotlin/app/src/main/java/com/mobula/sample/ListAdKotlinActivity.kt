package com.mobula.sample

import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import com.duapps.ad.AdError
import com.duapps.ad.DuAdDataCallBack
import com.duapps.ad.entity.strategy.NativeAd
import com.duapps.ad.list.AdListArrivalListener
import com.duapps.ad.list.DuNativeAdsManager
import com.mobula.sample.util.ImageLoaderKotlinHelper
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.assist.FailReason
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener
import kotlinx.android.synthetic.main.ad_card_kt.*

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/13-10:52
 */
class ListAdKotlinActivity : Activity() {
    var TAG = ListAdKotlinActivity::class.java.simpleName
    val PID = 10032
    val CACHESIZE = 10
    lateinit var mDuNativeAdsManager: DuNativeAdsManager
    lateinit var mImageLoader: ImageLoader

    val mAdList = arrayListOf<NativeAd>()
    val mHandler = Handler()

    var mPositon = 0;
    lateinit var mNativeAD: NativeAd
//    lateinit var mRunnable: Runnable


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ad_card_kt)

        mImageLoader = ImageLoaderKotlinHelper.getInstance(this)
        mDuNativeAdsManager = DuNativeAdsManager(this, PID, CACHESIZE).apply {
            setListener((object : AdListArrivalListener {

                override fun onAdLoaded(p0: MutableList<NativeAd>?) {
                    Log.d(TAG, "onAdLoaded")
                    mAdList?.clear()
                    p0?.forEach {
                        if (it != null) mAdList.add(it)
                    }
                    if (mAdList.size == CACHESIZE) {
                        mHandler.apply {
                            removeCallbacksAndMessages(null)
                            post(mRunnable)
                        }
                    }
                }

                override fun onAdError(p0: AdError?) {
                    Log.d(TAG, "onError : " + p0?.getErrorCode());
                }

            }))
        }

        Log.d(TAG, "load list ad....")
        mDuNativeAdsManager.load()
    }

    private val mRunnable = object : Runnable {
        override fun run() {
            if (mPositon < mAdList.size) {
                mNativeAD = mAdList.get(mPositon);
                mNativeAD.setMobulaAdListener(callback);
                val url = mNativeAD.adCoverImageUrl
                if (url.isEmpty()) showSmallAdView(mNativeAD) else showBigAdView(mNativeAD)

                mPositon++

            } else {
                mPositon = 0
            }
            mHandler.postDelayed(this, 8000)
        }
    }


    var callback = (object : DuAdDataCallBack {
        override fun onAdClick() {
            Log.d(TAG, "onClick : click list ad");
        }

        override fun onAdLoaded(p0: NativeAd?) {
            Log.d(TAG, "onAdLoaded: adloead list ad")
        }

        override fun onAdError(p0: AdError?) {
            Log.d(TAG, "onAdError: onAdError list ad:" + p0.toString())
        }

    })


    private fun showSmallAdView(ad: NativeAd?) {
        small_card_kt_name.text = ad?.adTitle
        small_card_kt_rating.rating = ad?.adStarRating ?: 4.0f
        mImageLoader.apply {
            displayImage(ad?.adIconUrl, small_card_kt_icon)
        }
        small_card_kt_des.text = ad?.adBody
        small_card_kt_btn.text = ad?.adCallToAction
        ad?.registerViewForInteraction(small_card_kt_btn)

        big_kt_ad?.visibility = View.GONE
        small_kt_ad.visibility = View.VISIBLE
        load_kt_view.visibility = View.GONE
        white_kt_bg.visibility = View.GONE
    }

    private fun showBigAdView(ad: NativeAd?) {

        small_kt_ad.visibility = View.GONE
        big_kt_ad.visibility = View.VISIBLE
        card_kt_name.text = ad?.adTitle
        card_kt_rating.rating = ad?.adStarRating ?: 4.0f
        card_kt_des.text = ""
        card_kt_btn.text = ad?.adCallToAction
        white_kt_bg.visibility = View.GONE
        mImageLoader.apply {
            displayImage(ad?.adIconUrl, card_kt_icon)
            displayImage(ad?.adCoverImageUrl, card_kt_image, (object : ImageLoadingListener {
                override fun onLoadingComplete(p0: String?, p1: View?, p2: Bitmap?) {
                    load_kt_view.visibility = View.GONE
                }

                override fun onLoadingStarted(p0: String?, p1: View?) {
                }

                override fun onLoadingCancelled(p0: String?, p1: View?) {
                }

                override fun onLoadingFailed(p0: String?, p1: View?, p2: FailReason?) {
                }

            }))
        }
        ad?.registerViewForInteraction(card_kt_btn)
    }

    override fun onDestroy() {
        super.onDestroy()
        mDuNativeAdsManager.apply {
            setListener(null)
            destroy()
        }
    }


}