package com.mobula.sample

import android.app.Application
import android.content.Context
import android.util.Log
import com.duapps.ad.base.DuAdNetwork
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.Closeable

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/15-20:17
 */
class MobulaKotlinApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        DuAdNetwork.setConsentStatus(this, true)
        DuAdNetwork.getConsentStatus(this)
        /**
         * the sdk initialization 初始化SDK
         */
        DuAdNetwork.init(this, getConfigJSON(getApplicationContext()))
    }

    fun getConfigJSON(context: Context): String {
        var bos = ByteArrayOutputStream()
        var bis = BufferedInputStream(context.assets.open("json.txt"))

        try {
            var readLen = -1
            while (bis.read().also { readLen = it } != -1) {
                bos.write(readLen)
            }

        } catch (e: Exception) {
            Log.e("", "IOException :" + e.message)
        } finally {
            closeQuietly(bis)
        }
        return bos.toString()
    }


    fun closeQuietly(closeable: Closeable) {
        try {
            closeable.close()
        } catch (e: Exception) {
        }
    }


}