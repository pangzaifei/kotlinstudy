package com.google.android.gms.example.bannerexample

import android.app.Activity
import android.os.Bundle
import android.util.Log

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2018/12/12-20:18
 */
//https://blog.csdn.net/pangzaifei/article/details/84978663
class KotlinList : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        testReadList()
        testMutableListOf()
        testReadSet()
        testMutableSet()
        testMapOf()
        testMutableMapOf()

        fun2()
        fun3()
        fun4()
    }

    fun testReadList() {
        var readList = listOf<String>("a", "b", "c", "d", "e", "f")
        //1.常用读取
        val value1 = readList.get(1)
        //2.常用读取
        val value2 = readList[1]
        //3.获取Index
        val indexOf = readList.indexOf("b")
        Log.e("fffpzf", "位置为1的数值value1:$value1,位置为1的数值value2:$value2,数值是b对应的index:$indexOf")

        readList.forEach {
            //遍历list
            Log.e("fffpzf", "遍历readList:$it")
        }
    }

    fun testMutableListOf() {
        val mutableListOf = mutableListOf<String>()
        mutableListOf.add("a")
        mutableListOf.add("b")
        mutableListOf.add("c")
        mutableListOf.add("d")
        //1.常用读取
        val value1 = mutableListOf.get(1)
        //2.常用读取
        val value2 = mutableListOf[1]
        //3.获取Index
        val indexOf = mutableListOf.indexOf("b")
        Log.e("fffpzf", "位置为1的数值value1:$value1,位置为1的数值value2:$value2,数值是b对应的index:$indexOf")
        mutableListOf.forEach {
            //遍历list
            Log.e("fffpzf", "遍历MutableListof:$it")
        }
    }


    fun testReadSet() {
        val setOf = setOf<String>("set_a", "set_b", "set_c")
        setOf.forEach {
            if (it == "set_a") Log.e("fffpzf", "获取到:set_a") else Log.e("fffpzf", "我是:$it")
        }
    }

    fun testMutableSet() {
        val setOf = mutableSetOf<String>()
        setOf.add("set_a")
        setOf.add("set_b")
        setOf.add("set_c")
        setOf.forEach {
            if (it == "set_a") Log.e("fffpzf", "获取到:set_a") else Log.e("fffpzf", "我是:$it")
        }
    }


    //map中定义key:value需要使用关键字 to
    fun testMapOf() {
        val mapOf = mapOf<String, String>("a" to "map1", "b" to "map2", "c" to "map3")
        //获取value形式1
        val value1 = mapOf["a"]
        //获取value形式2
        val value2 = mapOf.get("a")
        //获取keys集合
        val keys = mapOf.keys
        //获取values集合
        val values = mapOf.values

        Log.e("fffpzf", "value1:$value1,value2:$value2,keys:$keys,values:$values")
        //遍历
        mapOf.forEach {
            Log.e("fffpzf", "遍历mapOf:key=${it.key},value=${it.value}")
        }
    }

    //map中定义key:value需要使用关键字 to
    fun testMutableMapOf() {
//        val mapOf = mapOf<String, String>("a" to "map1", "b" to "map2", "c" to "map3")
        val mutableMapOf = mutableMapOf<String, String>()
        mutableMapOf.put("a", "map1")
        mutableMapOf.put("b", "map2")
        mutableMapOf.put("c", "map3")
        //获取value形式1
        val value1 = mutableMapOf["a"]
        //获取value形式2
        val value2 = mutableMapOf.get("a")
        //获取keys集合
        val keys = mutableMapOf.keys
        //获取values集合
        val values = mutableMapOf.values

        Log.e("fffpzf", "value1:$value1,value2:$value2,keys:$keys,values:$values")
        //遍历
        mutableMapOf.forEach {
            Log.e("fffpzf", "遍历mutableMapOf:key=${it.key},value=${it.value}")
        }

        for (mutableEntry in mutableMapOf) {
            Log.e("fffpzf", "key:${mutableEntry.key},value:${mutableEntry.value}")
        }


    }

//======lamabda begin======

    // 一个函数返回了一个内部函数，该内部函数引用了外部函数的相关参数和变量，我们把该返回的内部函数称为闭包。
    fun fun1(): () -> Int {
        var out = 1
        return {
            out + 5//引用外了外部函数中的out参数变量。把这个叫为闭包
        }
    }

//    fun fun2(n1: Int, n2: Int, (Int, Int)->Int):Int
//    {
//        return 1
//    }

    fun test2(n1: Int, n2: Int, testFun: (Int, Int) -> Int): Int {
        return testFun(n1, n2)
    }

    fun test3Add(num1: Int, num2: Int): Int {
        return num1 + num2
    }

    fun test3Multiply(num1: Int, num2: Int): Int {
        return num1 * num2
    }

    //创建了test2()第三个参数是函数类型，所以test2就是高阶函数。第三个参数可以接受函数类型，可接收的范围是(Int,Int)->Int的，就是test3Add()和test3Multiply()这两个函数
    //调用test2()方法，第三个参数选择传入test3Add()或者test3Multiply()就可以相加或者相乘的操作
    fun fun2() {
        //获取相加结果
        val addResult = test2(10, 5, this::test3Add)
        Log.e("fffpzf", "函数引用(::)获取到相加结果:$addResult")
        //获取相城结果
        val multiplayResult = test2(10, 5, this::test3Multiply)
        Log.e("fffpzf", "函数引用(::)获取到相乘结果:$multiplayResult")

    }

    fun fun3() {
        val test2 = test2(10, 5, { m, n -> m + n })
        Log.e("fffpzf", "lambda表达式初步变形结果:$test2")
    }

    fun fun4() {
        //如果最后一个参数是lambda表达式，那么()可以前提，类似下面这种
        val test2 = test2(10, 5) { m, n -> m + n }
        Log.e("fffpzf", "lambda表达式有参变形结果:$test2")
    }

    fun fun5() {
        //如果lamdba是无参数的，在forEach{}中就是

        val setOf = mutableSetOf<String>()
        setOf.add("set_a")
        setOf.add("set_b")
        setOf.add("set_c")
        setOf.apply {

        }
        setOf.forEach {
            if (it == "set_a") Log.e("fffpzf", "获取到:set_a") else Log.e("fffpzf", "我是:$it")
        }


        //下面这是forEach的源码，我们发现里面只有一个action: (T) -> Unit高阶函数，所以我们为什么在用forEach{}遍历的时候就直接用{}
        //同时如果只有一个参数可以省略参数名，然后用it来替代它。这也就是为什么forEach{}中可以用it
//        @kotlin.internal.HidesMembers
//        public inline fun <T> Iterable<T>.forEach(action: (T) -> Unit): Unit {
//            for (element in this) action(element)
//        }
    }

    fun fun6() {
        val setOf = mutableSetOf<String>()
        setOf.add("set_a")
        setOf.add("set_b")
        setOf.add("set_c")
        setOf.add("set_b")
        setOf.forEach {
            if (it == "set_a") Log.e("fffpzf", "获取到:set_a") else Log.e("fffpzf", "我是:$it")
        }

        var index = setOf.indexOfFirst {
            //找到第一个叫set_b的下表
            it.startsWith("set_b")
        }
        Log.e("fffpzf", "第一个set_b下表:$index")


        val str = setOf.find {
            it.startsWith("set")
        }
        Log.e("fffpzf", "找到第一个set开头的全名:$str")
//        setOf.filter {
//            //过滤
//
//        }
//        setOf.sortedBy {
//            //排序
//        }
//
//        setOf.groupBy {
//            //分组
//        }

    }


//    fun startMainActivity() {
//        startActivity(Intent(this, MainActivity::class.java))
//    }
    //=====lamabda end====


    //apply()、with（）、let()、run() begin

    //第一种 普通函数 b
    fun getA(test: () -> Unit) {
    }

    //调用getA
    fun useGetA() {
        getA {

        }
    }
    //第一种 普通函数 e

    //第二种 用T.()的内部函数 b
    fun getB(test: C.() -> Unit) {
        //在里面还以直接使用C中的方法d()
        C().d()
    }

    fun useGetB() {
        getB {
            //这个时候里面多了this参数，this指向的是C这个类
            this.d()
        }
    }

    class C {
        var params = "p"
        fun d() {

        }
    }
    //第二种 用T.()的内部函数 e

    //fun中使用
    fun testWith() {
        var d = with("abc") {
            var c = C() //如果最后一行是c,那么上面var d的类型是unit
            "a"//如果最后一行是"a",那么上面var d的类型是String
            1//如果最后一行是数字1,那么上面var d的类型是int
        }
        var aaa = arrayListOf<String>().apply {}
    }

    //类中使用
    class e {
        var ccc = with("abc") {}

        var ddd = let {

        }
    }

    class testLet {
        fun testLet() {
            var list = mutableListOf<String>()
            list.add("a")
            var letResult = list.let {
                //it代表的是list
                "a"//letResult结果是String
                1 //letResult结果是int
                it//letResult结果是int结果是MutableList<String>
            }
        }
    }

    class testRun {
        fun testRun() {
            var list = mutableListOf<String>()
            list.add("a")
            var runResult = list.run {
                "a"//letResult结果是String
                1 //letResult结果是int
                this//letResult结果是int结果是MutableList<String>
            }

            list.apply {

            }
        }
    }


    //apply()、with（）、let()、run() end

}

var ccc = with("abc") {}
