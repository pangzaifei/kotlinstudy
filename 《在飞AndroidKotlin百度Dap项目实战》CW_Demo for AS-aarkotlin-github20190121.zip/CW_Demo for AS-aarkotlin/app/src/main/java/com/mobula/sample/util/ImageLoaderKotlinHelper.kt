package com.mobula.sample.util

import android.content.Context
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/13-20:37
 */

object ImageLoaderKotlinHelper {
    var mIsInited = false
    var mShouldToolboxInitImageLoader = true

    fun disableToolboxInitImageLoader() {
        mShouldToolboxInitImageLoader = false
    }

    fun initImageLoader(context: Context) {
        var config = ImageLoaderConfiguration.Builder(context).diskCacheSize(10 * 1024 * 1024)// 10MB
                .build();
        ImageLoader.getInstance().init(config)
    }

    fun getInstance(context: Context): ImageLoader {
        if (mShouldToolboxInitImageLoader && !mIsInited) {
            synchronized(ImageLoaderKotlinHelper::class.java) {
                if (mShouldToolboxInitImageLoader && !mIsInited) {
                    initImageLoader(context)
                    mIsInited = true
                }
            }
        }
        return ImageLoader.getInstance();
    }


}

