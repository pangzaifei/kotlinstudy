package com.mobula.sample

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.FrameLayout.LayoutParams
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.RelativeLayout
import android.widget.TextView
import com.duapps.ad.AdError
import com.duapps.ad.DuAdListener
import com.duapps.ad.DuNativeAd
import com.google.android.gms.ads.formats.NativeAppInstallAdView
import com.google.android.gms.ads.formats.NativeContentAdView
import com.mobula.sample.util.ImageLoaderKotlinHelper
import com.nostra13.universalimageloader.core.ImageLoader
import kotlinx.android.synthetic.main.ad_container_layout.*

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/15-20:03
 */
class ShowADCardKotlinActivity : Activity() {

    var TAG = ShowADCardKotlinActivity::class.java.simpleName
    lateinit var nativeAd: DuNativeAd
    lateinit var imageLoader: ImageLoader
    val PID = 11279
    val DEFAULT_CACHE_SIZE = 2
    lateinit var rl: View
    lateinit var titleView: TextView
    lateinit var iconView: ImageView
    lateinit var ratingView: RatingBar
    lateinit var descView: TextView
    lateinit var bigImgView: ImageView
    lateinit var btnView: TextView
    lateinit var bigImgContainer: RelativeLayout
    lateinit var lp: LayoutParams
    lateinit var installAdView: NativeAppInstallAdView
    lateinit var contentAdView: NativeContentAdView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ad_container_layout)

//        adItem = layoutInflater.inflate(R.layout.ad_card_item_layout, adlayout, false)
        imageLoader = ImageLoaderKotlinHelper.getInstance(this)
        initView()

        nativeAd = DuNativeAd(this, PID, DEFAULT_CACHE_SIZE);
        nativeAd.setMobulaAdListener(mListener)
        Log.d(TAG, "load...");
        nativeAd.load()
        var test1:String? = null//test1是可空的
        test1?.split("a")?:"bbbbb"//调用的时候需要来判断是否空，如果是空则test1=默认值"bbbb",如果不是空执行split("a")
        lateinit var test2:String//test2是不为空的
        test2.split("a")//调用的时候可以不判断直接使用


    }

    fun initView() {
        rl = layoutInflater.inflate(R.layout.ad_card_item_layout, adlayout, false)
        titleView = rl.findViewById(R.id.card_name) as TextView
        if(titleView is TextView){}
        iconView = rl.findViewById(R.id.card_icon) as ImageView
        ratingView = rl.findViewById(R.id.card_rating) as RatingBar
        descView = rl.findViewById(R.id.card__des) as TextView
        bigImgView = rl.findViewById(R.id.card_image) as ImageView
        btnView = rl.findViewById(R.id.card_btn) as TextView
        bigImgContainer = rl.findViewById(R.id.big_ad) as RelativeLayout
    }

    var mListener = object : DuAdListener {
        override fun onClick(p0: DuNativeAd?) {
            Log.d(TAG,  "onClick")
        }

        override fun onError(p0: DuNativeAd?, p1: AdError?) {
            Log.d(TAG,  "onError")
        }

        override fun onAdLoaded(ad: DuNativeAd?) {
            Log.d(TAG,  "onAdLoaded")

            runOnUiThread {
                if (ad != null) {
                    adlayout.removeAllViews()
                }
                titleView.text = ad?.title
                ratingView.rating = ad?.ratings ?: 4F
                imageLoader.displayImage(ad?.iconUrl, iconView)
                imageLoader.displayImage(ad?.imageUrl, bigImgView)
                descView.text = ad?.shortDesc
                btnView.text = ad?.callToAction

                // If the type of Ad is “Admob- AppInstall”, then dynamically use the “NativeAppInstallAdView” provided by Admob
                //判断广告类型,如果是Admob的AppInstall类型广告,则动态使用Admob提供的NativeAppInstallAdView

                if (ad?.getAdChannelType() == DuNativeAd.CHANNEL_TYPE_AM_INSTALL) {
                    if (lp == null) {
                        lp = LayoutParams(LayoutParams.WRAP_CONTENT,
                                LayoutParams.WRAP_CONTENT)
                    }
                    if (installAdView == null) {
                        installAdView = NativeAppInstallAdView(this@ShowADCardKotlinActivity)
                    }
                    installAdView.setHeadlineView(titleView);
                    installAdView.setIconView(iconView);
                    installAdView.setBodyView(descView);
                    installAdView.setImageView(bigImgView);
                    installAdView.setStarRatingView(ratingView);
                    installAdView.setCallToActionView(btnView);
                    installAdView.addView(rl, lp);
                    adlayout.removeAllViews()
                    adlayout.addView(installAdView)

                    /* When registering the View of Ad in type  “Admob- AppInstall”, “NativeAppInstallAdView” need to be registered.
                     * Otherwise, clicking the Ad will be failed and the impression of Ad will be invalid.
                     */
                    /*注册admob AppInstall类型广告View的时候,需要注册NativeAppInstallAdView,
                     *否则广告无法点击跳转,此展示无效.
                     */
                    nativeAd.registerViewForInteraction(installAdView);

                }


                // If the type of AD is “Admob- Content”, then dynamically use the  “NativeContentAdView” provided by Admob
                //判断广告类型,如果是admob的content类型广告,则动态使用admob提供的NativeContentAdView

                else if (ad?.getAdChannelType() == DuNativeAd.CHANNEL_TYPE_AM_CONTENT) {
                    if (lp == null) {
                        lp = LayoutParams(LayoutParams.WRAP_CONTENT,
                                LayoutParams.WRAP_CONTENT);
                    }
                    if (contentAdView == null) {
                        contentAdView = NativeContentAdView(this@ShowADCardKotlinActivity)
                    }
                    contentAdView.headlineView = titleView
                    contentAdView.logoView = iconView
                    contentAdView.bodyView = descView
                    contentAdView.imageView = bigImgView
                    contentAdView.callToActionView = btnView
                    contentAdView.addView(rl, lp);
                    adlayout.removeAllViews()
                    adlayout.addView(contentAdView);

                    /* When registering the View of Ad in type  “Admob- Content”, “NativeContentAdView” need to be registered.
                     * Otherwise, clicking the Ad will be failed and the impression of Ad will be invalid.
                     */
                    /*注册admob content类型广告View的时候,需要注册NativeContentAdView,
                     *否则广告无法点击跳转,此展示无效.
                     */

                    nativeAd.registerViewForInteraction(contentAdView);
                }


                // If the type of Ad is “Facebook” or “DU”, please use the below method to register the View.
                // 广告类型是DuNativeAd.DAP_NORMAL_AD( FB & DU )的时候,请按下面方式注册广告View.

                else {
                    adlayout.addView(rl);
                    nativeAd.registerViewForInteraction(bigImgContainer);
                }

            }

        }
    }


    override fun onDestroy() {
        super.onDestroy()
        nativeAd.destory()
    }
}