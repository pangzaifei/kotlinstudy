package com.mobula.sample

import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.util.Log
import android.view.View
import com.duapps.ad.AdError
import com.duapps.ad.DuAdListener
import com.duapps.ad.DuNativeAd
import com.mobula.sample.util.ImageLoaderKotlinHelper
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.assist.FailReason
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener
import kotlinx.android.synthetic.main.ad_card_kt.*  //kotlin加载布局，可以省去java中的findviewbyid操作

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/15-19:40
 */
class ShowAdKotlinActivity : Activity() { //ShowAdKotlinActivity继承Activity   :是继承的意思  Activity()表示具体的类 ，对应java:ShowAdKotlinActivity extends Activity{}
    var TAG = ShowAdKotlinActivity::class.java.simpleName //::是函数引用,使用ShowAdKotlinActivity::class.java.simpleName作为Log的Tag,对应java: private static final String TAG = ShowAdKotlinActivity.class.getSimpleName();知识点： https://blog.csdn.net/pangzaifei/article/details/85076557
    lateinit var mImageLoader: ImageLoader  //定义一个成员变量mImageLoader 类型是IMageLoader的  lateinit是告诉编译器mimageLoader需要在用的时候去赋值，在声明的时候不需要赋值,lateinit修饰var
    lateinit var mDuNativeAd: DuNativeAd  //定义一个成员变量mDuNativeAd 类型是com.duapps.ad.DuNativeAd的  lateinit是告诉编译器mimageLoader需要在用的时候去赋值，在声明的时候不需要赋值，lateinit修饰var   知识点:https://blog.csdn.net/pangzaifei/article/details/85163500
    val PID = 10032   //val 是final的，一般修饰常量.所以PID=10032就对应java中  private final int PID = 10032;
    val CACHESZIE = 2  //val 是final的，一般修饰常量.所以CACHESZIE = 2 就对应java中  private final int CACHESZIE = 2;
    override fun onCreate(savedInstanceState: Bundle?) { //override重载 onCreate()方法
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ad_card_kt)  //设置布局
        mImageLoader = ImageLoaderKotlinHelper.getInstance(this)  //初始化ImageLoader,此类是工具类，在com.mobula.sample.util.ImageLoaderKotlinHelper路径中
        mDuNativeAd = DuNativeAd(this, PID, CACHESZIE).apply {
            //dap sdk初始化,参数分别contet,广告sid，缓存个数   apply{}可以让一组操作放在一起，其中it代表的是mDunatvieAd对象   知识点:https://blog.csdn.net/pangzaifei/article/details/85118937
            setMobulaAdListener((object : DuAdListener {   //setMobulaAdListener((object : DuAdListener { }设置广告的回调   相当java： mDuNativeAd.setMobulaAdListener(new DuAdListener() {})
                override fun onAdLoaded(ad: DuNativeAd?) { //重载广告接在成功回调，ad:DunatvieA? 参数ad是DuNativeAd类型，DunativeAd?这个问号标识ad是可为null的  知识点：见本文开头
                    Log.d(TAG, "onAdLoaded")  //输出log
                    runOnUiThread {
                        //在Ui线程更新ui
                        var url: String? = imageUrl    //判断是否有大图图片的Url
                        if (url == null) showSmallAdView(ad) else showBigAdView(ad)//如果有大图图片的url就去加载显示big的布局，没有就去展示small的布局
                    }
                }
                override fun onClick(ad: DuNativeAd?) {//广告点击回调 ，ad:DunatvieA? 参数ad是DuNativeAd类型，DunativeAd?这个问号标识ad是可为null的
                    Log.d(TAG, "onClick")
                }
                override fun onError(ad: DuNativeAd?, error: AdError?) {//广告返回错误回到   ad:DunatvieA? 参数ad是DuNativeAd类型，DunativeAd?这个问号标识ad是可为null的  p1:AdError? 参数ad类型是AdError类型的，同时ad是可为null的
                    Log.d(TAG, "onError${error?.errorCode}")//输出错误信息，?.表示：error如果不为null的时候调用error.errorCode，如果error为Null则不处理。相当于java:            if (error != null) { Log.d(TAG, "onError : " + error.getErrorCode()); }
                }
            }))
        }
        mDuNativeAd.load()
    }
    //显示小图布局
    private fun showSmallAdView(ad: DuNativeAd?) {
        small_card_kt_name.text = ad?.title   //设置广告的title
        small_card_kt_rating.rating = ad?.ratings ?: 4.0f  //设置广告的平行，如果有就ad.ratings如果没有就默认4.0分
        mImageLoader.apply {    //Imageload去加载图片
            displayImage(ad?.iconUrl, small_card_kt_icon) //加载iconUrl，将图片当道small_card_kt_icon这个imageview中
        }
        small_card_kt_des.text = ad?.shortDesc   //设置广告的短描
        small_card_kt_btn.text = ad?.callToAction   //设置广告点击跳转按钮的文案
        ad?.registerViewForInteraction(small_card_kt_btn)  //注册广告点击跳转区域为small_card_kt_btn
        big_kt_ad?.visibility = View.GONE   //设置是否可见
        small_kt_ad.visibility = View.VISIBLE   //设置是否可见
        load_kt_view.visibility = View.GONE   //设置是否可见
        white_kt_bg.visibility = View.GONE   //设置是否可见
    }

    private fun showBigAdView(ad: DuNativeAd?) {
        small_kt_ad.visibility = View.GONE    //设置是否可见
        big_kt_ad.visibility = View.VISIBLE     //设置是否可见
        card_kt_name.text = ad?.title      //设置广告的title
        card_kt_rating.rating = ad?.ratings ?: 4.0f    //设置广告的平行，如果有就ad.ratings如果没有就默认4.0分
        card_kt_des.text = ""          //设置广告的短描
        card_kt_btn.text = ad?.callToAction    //设置广告点击跳转按钮的文案
        white_kt_bg.visibility = View.GONE   //设置是否可见
        mImageLoader.apply {     //Imageloader去加载图片，将图片处理放在apply中批量处理
            displayImage(ad?.iconUrl, card_kt_icon)   //加载icon，将图片放到card_kt_icon控件中
            displayImage(ad?.imageUrl, card_kt_image, (object : ImageLoadingListener {  //加载大图，将大图放到card_kt_image中，同时添加imageloadListener回调
                override fun onLoadingComplete(p0: String?, p1: View?, p2: Bitmap?) {  //图片完成回调
                    load_kt_view.visibility = View.GONE
                }
                override fun onLoadingStarted(p0: String?, p1: View?) {//start回调
                }
                override fun onLoadingCancelled(p0: String?, p1: View?) {//cancel回调
                }
                override fun onLoadingFailed(p0: String?, p1: View?, p2: FailReason?) {//Failed回调
                }

            }))
        }
        ad?.registerViewForInteraction(card_kt_btn)//注册广告点击跳转区域为small_card_kt_btn
    }

    //showBigAdView的java实现:可以做对比
//    /**
//     * show big ad 显示da图广告
//     *
//     * @param ad
//     */
//    private void showBigAdView(DuNativeAd ad) {
//        smallADLayout.setVisibility(View.GONE);
//        bigADLayout.setVisibility(View.VISIBLE);
//        titleView.setText(ad.getTitle());
//        ratingView.setRating(ad.getRatings());
//        imageLoader.displayImage(ad.getIconUrl(), iconView);
//        descView.setText("");
//        btnView.setText(ad.getCallToAction());
//        bgView.setVisibility(View.GONE);
//        nativeAd.registerViewForInteraction(btnView);
//        imageLoader.displayImage(ad.getImageUrl(), bigImgView, new ImageLoadingListener() {
//            @Override
//            public void onLoadingStarted(String paramString, View paramView) {
//            }
//            @Override
//            public void onLoadingFailed(String paramString, View paramView, FailReason paramFailReason) {
//            }
//            @Override
//            public void onLoadingComplete(String paramString, View paramView, Bitmap paramBitmap) {
//                loadView.setVisibility(View.GONE);
//            }
//            @Override
//            public void onLoadingCancelled(String paramString, View paramView) {
//            }
//        });
//    }
}