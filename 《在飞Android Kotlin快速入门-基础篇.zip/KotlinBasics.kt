package com.google.android.gms.example.bannerexample

import android.app.Activity
import android.os.Bundle
import android.util.Log

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/12-14:53
 */
class KotlinBasics : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        test运算符重载()
        testConstructor()
        test继承()
        test接口()
        test多态()
        test内部类()
        test泛型擦除()
    }

    private fun test运算符重载() {
        var pro = Programmer()
        Log.e("fffpzf", "pro_level:${pro.level}pro_money:${pro.money}")
        pro++
        pro++
        Log.e("fffpzf", "升级后pro_level:${pro.level}，pro_money:${pro.money}")
    }

    class Programmer {
        var level = 0
        var money = 10000

        operator fun inc(): Programmer {
            level++
            money = (money * 1.2).toInt()
            return this
        }
    }


    //构造函数
    //test Constructor begin
    private fun testConstructor() {
        var programmer = Programeer("张", 24, 157)
    }

    class Programeer(var name: String, var age: Int) {
        constructor(name: String, age: Int, phone: Int) : this(name, age) {
            Log.e("fffpzf", "constructor....,name=${name},age=${age},phone=${phone}")
        }
    }
    //test Constructor end


    //test 继承begin
    private fun test继承() {
        //注意：Kotlin默认类final的所以不能被继承，我们需要open关键字来允许继承
        var father = Father()
        father.writeNovel()
        var son = Son()
        son.writeNovel()

    }

    open class Father {
        open var name = "张一"
        var age = 60
        //open 允许子类重载writeNovel方法，如果没有open子类无法重载
        open fun writeNovel() {
            Log.e("fffpzf", "father=${name},写历史小说...")
        }
    }

    class Son : Father() {
        override var name = "张二"
        //        age （Father中age不是open所以无法重载）
        override fun writeNovel() {
//            super.writeNovel()
            Log.e("fffpzf", "son=${name},写玄幻小说....")
        }
    }
    //test 继承end

    //test 接口begin
    interface Ball {
        fun footBall()
        fun basketBall()
    }

    fun test接口() {
        var zs = zhangsan()
        zs.basketBall()
        zs.footBall()
    }

    class zhangsan : Object(), Ball {
        override fun footBall() {
            Log.e("fffpzf", "张三会足球。。")
        }

        override fun basketBall() {
            Log.e("fffpzf", "张三不会篮球。。")
        }
    }
    //test 接口end

    //test 多态begin
    open class Water {
        open fun color() {}
    }

    class YellowRiver : Water() {
        override fun color() {
            Log.e("fffpzf", "黄河水黄色...")
        }
    }

    class QinghaiLake : Water() {
        override fun color() {
            Log.e("fffpzf", "青海湖透明...")
        }
    }


    fun test多态() {
        var yellowRiver = YellowRiver()
        yellowRiver.color()
        var qingHaiRiver: Water = QinghaiLake()
        if (qingHaiRiver is QinghaiLake) {
            var q = qingHaiRiver as QinghaiLake
            q.color()
        }
    }
    //test 多态end


    //test嵌套类与内部类 begin

    //嵌套类是static的不能访问外部类中的字段，inner修饰的内部类可以访问外部类中的字段，如果inner类想访问外部类中的相同字段可以用this
    class OutClass {
        var name = "张三"

        inner class InnerClass {
            var name = "李四"
            fun eat() {
                Log.e("fffpzf", "${this.name}:吃饭...")
            }
        }
    }

    fun test内部类() {
        var o = OutClass()
        o.InnerClass().eat()
    }
    //test嵌套类与内部类 end


    //test泛型与泛型上限begin
    open class Parent<T>(var t: T) {

    }

    //使用泛型
    class Son1 : Parent<String>("") {}
    class Son2<T>(t:T) : Parent<Int>(1) {}

    fun test泛型() {
        var son1=Son1()
        var son2=Son2<String>("")
    }
    //泛型上限：指定T的范围是Son1及其子类
    class Son3<T:Son1>(t:T) : Parent<Int>(1) {}
    fun test泛型上限(){
//        var p=Parent<Int>(1)
//        var ss=Son3<Parent>(p)//错误,因为T的上限是Son1
        var s1=Son1()
        var ss1=Son3<Son1>(s1)
    }
    //test泛型与泛型上限end

    //解决泛型擦除 begin   inline+reified
    fun test泛型擦除(){
        Log.e("fffpzf","获取T.className:"+test2("asdv"))
    }

//    fun <T> test1(t:T){
//        T::class.java.name//这地报错，因为泛型被擦除了，所以无法找到::class.java.namae
//    }
    //解决泛型擦除
    inline fun <reified T> test2(t:T): String? {
       return T::class.java.name
    }

    //解决泛型擦除 end

    //out关键字相当于java中的<? extends XXX> begin
    //同理in关键字相当于java中的<? super XXX>
    //*号同java中的<?>相同
   class TestOut{
        fun testOut1(list:ArrayList<out Father>){
        }

        fun testOut2(){
            var list=ArrayList<Father>()
            testOut1(list)
            var sonList=ArrayList<Son>()
            testOut1(sonList)//如果上面不加out这句话无法使用，因为kotlin会判断test1中的参数是Father类型的，及时子类也不行，所以需要out关键字修饰
        }
        fun testOut3(list:ArrayList<in Father>){
        }
        fun testOut4(list2:ArrayList<*>){
        }
    }
    //out关键字相当于java中的<? extends XXX>  end



}
