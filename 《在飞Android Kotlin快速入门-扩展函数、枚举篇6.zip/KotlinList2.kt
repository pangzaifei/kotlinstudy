package com.google.android.gms.example.bannerexample

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.util.Log

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2018/12/21-15:35
 */
class KotlinList2 : Activity() {
    //by lazy
    val testByLazy by lazy {
        Log.e("fffpzf", "初始化bylazy..")
        10
    }
    //lateinit
    lateinit var testLateInit: String//在这用lateinit会报错


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DuInput.getInstance(this@KotlinList2).start()
        TestInstance.start2()
        Log.e("fffpzf", "testByLazy1:$testByLazy")
        Log.e("fffpzf", "testByLazy2:$testByLazy")
        val testEnum = testEnum()
        testEnum.getDay(Week.周一)
        testEnum.getDay(Week.周六)
        testEnum.testWeek1()


        val testExtends = testExtends()
        testExtends.testExtend1()
    }

    fun testByLazy() {
    }

}


//普通class的类testObject1及内部的普通参数testData
class testObject1 {
    var testData = 10
}

//object修饰的类testObject2及内部object修饰的参数testData2
object testObject2 {
    var testObjectData2 = 10
}

class DuInput internal constructor(private val mContext: Context) {
    companion object {
        private var mDuInput: DuInput? = null
        fun getInstance(context: Context): DuInput {
            if (mDuInput == null) {
                synchronized(DuInput::class.java) {
                    if (mDuInput == null) {
                        mDuInput = DuInput(context)
                    }
                }
            }
            return mDuInput!!
        }
    }

    fun start() {}
}


object TestInstance {
    fun start2() {}
}

//枚举begin
enum class Week {
    周一, 周二, 周三, 周四, 周五, 周六, 周日
}

class testEnum {
    //1.遍历枚举
    fun testWeek1() {
        val values = Week.values()
        values.forEach {
            Log.e("fffpzf", "testWeek1:遍历枚举:" + it.name)
        }
    }

    //2.when in
    fun getDay(week: Week) {
        when (week) {
            in Week.周一..Week.周五 -> Log.e("fffpzf", "getDay:工作日...")
            Week.周六 -> Log.e("fffpzf", "getDay:周六")
            Week.周日 -> Log.e("fffpzf", "getDay:周日")
        }
    }
}
//枚举end

//扩展函数begin
class testExtends {
    fun testExtend1() {
        var list = mutableListOf<String>()
        list.add("a")
        list.add("b")
        list.add("c")

        Log.e("fffpzf", "系统的isEmpty:" + list.isEmpty())
        Log.e("fffpzf", "自定义的空判断扩展函数mIsEmpty:" + list.mIsEmpty(list))
    }


    //自定义扩展函数,函数可以带函数
    fun MutableList<String>?.mIsEmpty(list: MutableList<String>): Boolean {
        if (this != null && this.size > 0) return false//this代表自身，MutableList<String>
        if (list != null && list.size > 0) return false//使用参数中的list
        return true
    }


}
//扩展函数end





