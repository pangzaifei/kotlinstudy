package com.mobula.sample

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.duapps.ad.DuNativeAd
import com.duapps.ad.PullRequestController
import com.duapps.ad.list.DuNativeAdsManager
import com.duapps.ad.offerwall.ui.OfferWallAct
import kotlinx.android.synthetic.main.main_layout.*

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/15-19:26
 */
class MainKotlinActivity : Activity() {
    var TAG = MainKotlinActivity::class.java.simpleName
    private val PID = 10032
    private val CACHESIZE = 2
    private val CACHESZIELIST = 10
    private lateinit var nativeAd: DuNativeAd
    private lateinit var adsManager: DuNativeAdsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_layout)
        onViewsClick()

    }

    fun onViewsClick() {
        fill_ad.setOnClickListener {

            nativeAd = DuNativeAd(this, PID, CACHESIZE).apply {
                fill()
            }
            adsManager = DuNativeAdsManager(this, PID, CACHESZIELIST).apply {
                fill()
            }
            Toast.makeText(this, "Fill the advertising", Toast.LENGTH_LONG).show()
        }

//        show_ad.setOnClickListener {
//            startActivity(Intent(this, ShowAdActivity::class.java))
//        }
//
//        list_ad.setOnClickListener {
//            startActivity(Intent(this, ListAdActivity::class.java))
//        }
        clean_ad.setOnClickListener {
            PullRequestController.getInstance(applicationContext).clearCache()
            Toast.makeText(this, "clean cache data success", Toast.LENGTH_LONG).show()
        }
        offerwall.setOnClickListener {

            var offerWallIntent = Intent(this, OfferWallAct::class.java)
            var bundle = Bundle()
            bundle.apply {
                putInt("pid", 61709);
                putInt(OfferWallAct.KEY_TITLE_ID, R.string.app_name); // 可选
                putString(OfferWallAct.KEY_TAB_BACKGROUND_COLOR, "#EDEDED"); // 可 选
                putString(OfferWallAct.KEY_TAB_INDICATOR_COLOR, "#1C86EE"); // 可选
                putString(OfferWallAct.KEY_TAB_TEXT_COLOR, "#000000"); // 可选
            }

            offerWallIntent.putExtras(bundle)
            startActivity(offerWallIntent)
        }


//        Interstitial_ad.setOnClickListener {
//            Interstitial_ad.isEnabled=false
//            Interstitial_ad.isClickable=false
//        }

//        Banner_ad.setOnClickListener {
//            startActivity(Intent(this, BannerAdActivity::class.java))
//        }
        interstitial_ad_kt.setOnClickListener {
            startActivity(Intent(this, InterstitialAdKotlinActivity::class.java))
        }
        banner_ad_kt.setOnClickListener {
            startActivity(Intent(this, BannerAdKotlinActivity::class.java))
        }
        show_ad_kt.setOnClickListener {
            startActivity(Intent(this, ShowAdKotlinActivity::class.java))
        }
        list_kt_ad.setOnClickListener {
            startActivity(Intent(this, ListAdKotlinActivity::class.java))
        }
        admob_ad_kt.setOnClickListener {
            startActivity(Intent(this, ShowADCardKotlinActivity::class.java))
        }


    }
}