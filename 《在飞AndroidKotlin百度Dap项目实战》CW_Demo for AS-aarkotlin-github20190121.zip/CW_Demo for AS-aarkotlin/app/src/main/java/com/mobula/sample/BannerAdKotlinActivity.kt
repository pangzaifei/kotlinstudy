package com.mobula.sample

import android.app.Activity
import android.os.Bundle
import android.util.Log
import com.duapps.ad.banner.*
import kotlinx.android.synthetic.main.ad_banner_card_kt.*

/**
 *
 * @author pangzaifei
 * @version v1.0
 * @date 2019/1/13-19:15
 */
class BannerAdKotlinActivity : Activity() {


    var TAG = BannerAdKotlinActivity::class.java.simpleName
    val PID = 10032
    lateinit var mBannerAdView: BannerAdView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ad_banner_card_kt)

        mBannerAdView = BannerAdView(this, PID, 5, BannerType.TYPE_CPA, (object : BannerListener {
            override fun onCpmAdLoaded() {
                Log.d(TAG, "onCpmAdLoaded")
            }

            override fun onCpmClicked() {
                Log.d(TAG, "onCpmClicked")
            }

            override fun onError(p0: String?) {
                Log.d(TAG, "onError")
            }

            override fun onAdLoaded() {
                Log.d(TAG, "onAdLoaded")
            }
        }))
        mBannerAdView.apply {
            setBgStyle(BannerStyle.STYLE_BLUE)
            setCloseStyle(BannerCloseStyle.STYLE_BOTTOM)
            banner_ad_kt_rl.removeAllViews()
            banner_ad_kt_rl.addView(this)
        }
        Log.d(TAG, "load banner...")
        mBannerAdView.load()
    }
}